#####################################################
# Title:        Final Project: Fulltext (CHN)
# Author:       Wei Tong An Richard (U3579291)
# Description:  Creating a fulltext table
#####################################################


setwd("C:/Users/user/Desktop/HKU Materials/Year 3/Y3S2/POLI3148 - Data Science/HW/Final Project/Code")

rm(list = ls())

library(tidyverse)
library(lubridate)
library(readxl)
library(readr)

corpus <- read_xlsx("data_cn/CMFA_PressCon_v3.xlsx") %>% 
  # Matching the time series with Australian dataset
  subset(date > "2010-01-01" & date < "2022-05-30") %>% 
  # Using the keys to subset relevant conference Q&As
  filter(str_detect(q_loc, "Australia") | str_detect(q_misc, "Australia") | str_detect(a_loc, "Australia") | str_detect(a_misc, "Australia")) %>% 
  select(id,link,date,question,answer) %>% 
  # Renaming it to be equivalent to the Australian dataset
  rename("uid" = "id") %>% 
  rename("url" = "link") %>% 
  rename("dates" = "date") %>%
  rename("title" = "question") %>% 
  rename("text" = "answer") %>% 
  # Roughly cut the length of answer as an ad hoc placeholder for the title
  mutate(title = str_sub(title, start = 1, end = 30))

write.csv(corpus, "data_cn/corpus.csv")

# Tokenisation
library(tidytext)
corpus_token <- corpus %>%
  unnest_tokens("word", "text")

# Stop words
library(DT)
DT::datatable(stop_words)

# Add meaningless words to stop words list
word <- c("chinese", "china", "china's", "australia", "australian", "australia's", "question", "journalist")
lexicon <- c("NEW", "NEW", "NEW", "NEW", "NEW", "NEW", "NEW", "NEW")

add_stop_words <- data.frame(word, lexicon)

new_stop_words <- full_join(stop_words, add_stop_words)


corpus_token_stop = corpus_token %>%
  # Remove tokenised words which match with the stop words
  anti_join(new_stop_words, by = "word")

# Stemming
library(SnowballC)

corpus_final = corpus_token_stop %>%
  mutate(stem = wordStem(word))


write.csv(corpus_final, "data_cn/corpus_final.csv")