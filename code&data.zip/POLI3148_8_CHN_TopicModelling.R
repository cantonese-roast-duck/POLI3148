#######################################################
# Title:        Final Project: Topic Modeling (CHN)
# Author:       Wei Tong An Richard (U3579291)
# Description:  Doing topic modeling
#######################################################

setwd("C:/Users/user/Desktop/HKU Materials/Year 3/Y3S2/POLI3148 - Data Science/HW/Final Project/Code")

rm(list = ls())

library(tidyverse)
library(tidytext)
library(lubridate)
library(topicmodels)
library(reshape2)
library(ggwordcloud)

fulltext <- read.csv("data_cn/corpus_final.csv") %>% 
  select(-"X")

# This is the tokenised but unstemmed one
fulltext_prelim <- read.csv("data_cn/corpus.csv") %>% 
  select(-"X")

## Calculate Document-level Term Frequencies
d_word_frequencies = fulltext %>%
  group_by(uid, stem) %>%
  count()

## Create Document-Term Matrix

dtm = d_word_frequencies %>% cast_dtm(uid, stem, n)

## Fit Topic Models
# Set number of topics (May look for more optimal calculation)
K = 8

# Set random number generator seed
set.seed(1122)

# compute the LDA model, inference via 1000 iterations of Gibbs sampling
m_tm = LDA(dtm, K, method="Gibbs", 
           control=list(iter = 500, verbose = 25))

## Clean Results of Topic Models
## beta: How words map to topics
sum_tm_beta = tidy(m_tm, matrix = "beta")  %>% 
  # Manual classification of topics
  mutate(topic = case_when(
    topic == "1" ~ "Economy and Trade",
    topic == "2" ~ "Sino-Aus Cooperation",
    topic == "3" ~ "COVID-19 Investigation",
    topic == "4" ~ "Xinjiang Camps",
    topic == "5" ~ "Hong Kong Protests",
    topic == "6" ~ "Human Rights",
    topic == "7" ~ "SCS and Pacific Islands",
    topic == "8" ~ "AUKUS Agreement"
    ))

## gamma: How documents map on topics
sum_tm_gamma = tidy(m_tm, matrix = "gamma") %>%
  rename("uid" = "document")   %>% 
  # Manual classification of topics
  mutate(topic = case_when(
    topic == "1" ~ "Economy and Trade",
    topic == "2" ~ "Sino-Aus Cooperation",
    topic == "3" ~ "COVID-19 Investigation",
    topic == "4" ~ "Xinjiang Camps",
    topic == "5" ~ "Hong Kong Protests",
    topic == "6" ~ "Human Rights",
    topic == "7" ~ "SCS and Pacific Islands",
    topic == "8" ~ "AUKUS Agreement"
  ))

## Visualize Topic Modeling Results

# Joining the sentiment scores to the gamma
chn_sentiments <- read.csv("data_cn/sentiments.csv") %>% 
  select(-"X")

chn_sentiments$uid <- as.character(chn_sentiments$uid)

sentiments_topics <- full_join(chn_sentiments, sum_tm_gamma, by = "uid")

# Setting the variable types
sentiments_topics <- na.omit(sentiments_topics)
sentiments_topics$dates <- as.Date(sentiments_topics$dates)
sentiments_topics$topic <- as.character(sentiments_topics$topic)
sentiments_topics$gamma <- as.numeric(sentiments_topics$gamma)

sentiments_topics$uid <- as.character(sentiments_topics$uid)

# Removing topic hits in documents when lower than 0.2
sentiments_topics <- sentiments_topics %>% 
  filter(sentiments_topics$gamma > 0.2) %>%
  # Creating the weighted sentiment scores
  mutate(weighted_sentiment_score = sentiment_score * gamma) %>% 
  
  # Removing two cases that do not belong to the topic of COVID-19 investigation
  # As they occurred before 2020
  filter(!uid == 10422) %>% 
  filter(!uid == 12898) %>% 
  
  # Removing the cases that were too early to belong to AUKUS deal
  filter(!uid == 7953) %>% 
  filter(!uid == 9226) %>% 
  filter(!uid == 13483) %>% 
  filter(!uid == 15133) %>% 
  filter(!uid == 15488) %>% 

  # Removing the cases that were too early to belong to HK Protests
  filter(!uid == 7632) %>% 
    filter(!uid == 7750) %>% 
    filter(!uid == 7758) %>% 
    filter(!uid == 7850) %>% 
    filter(!uid == 7854) %>% 
    filter(!uid == 7864) %>% 
    filter(!uid == 10051)

### Plot: How prevalent were certain topics over time
sentiments_topics %>%
  ggplot(aes(x = dates, y = gamma, colour = topic)) +
  geom_point(alpha = 0.2) + 
  geom_smooth(se = FALSE) +
  labs(
    title = "Topic Prevalence of Chinese Communication",
    colour = "Topics"
  ) +
  scale_x_date(breaks = scales::breaks_pretty(7)) +
  xlab("Date") + ylab("Gamma") + 
  theme(text = element_text(size = 15))  


### Plot: What were the sentiment scores of topics over time
sentiments_topics %>%
  ggplot(aes(x = dates, y = sentiment_score, colour = topic)) +
  geom_point(alpha = 0.2) + 
  geom_smooth(se = FALSE) +
  labs(
    title = "Sentiments of Chinese Communication by Topic",
    colour = "Topics"
  ) +
  scale_x_date(breaks = scales::breaks_pretty(7)) +
  xlab("Date") + ylab("Sentiment Scores (N)") + 
  theme(text = element_text(size = 15))  


# Choose number of most frequent words to show
TOP_N_WORD = 10

topic_top_word = sum_tm_beta %>%
  rename("word" = "term") %>%
  group_by(topic) %>%
  slice_max(beta, n = TOP_N_WORD) %>%
  arrange(topic, desc(beta))

topic_top_word$topic = as.character(topic_top_word$topic)

### Plot: Topics in barcharts

topic_top_word %>%
  mutate(word = reorder_within(word, beta, topic)) %>% 
  ggplot(aes(y = word, x = beta, fill = topic)) +
  geom_bar(stat = "identity") +
  facet_wrap(~topic, scales = "free_y") +
  scale_y_reordered() + # Very interesting function. Use with reorder_within
  labs(
    title = "Topic Modeling (China)",
    fill = "Topics"
  ) +
  xlab("Beta") + ylab("Top Words by Topic") + 
  theme(text = element_text(size = 15))  