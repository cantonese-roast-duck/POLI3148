#######################################################
# Title:        Final Project: Sentiment Analysis (AUS)
# Author:       Wei Tong An Richard (U3579291)
# Description:  Doing sentiment analysis
#######################################################

setwd("C:/Users/user/Desktop/HKU Materials/Year 3/Y3S2/POLI3148 - Data Science/HW/Final Project/Code")

rm(list = ls())

library(tidyverse)
library(tidytext)
library(textdata)

fulltext <- read.csv("data/fulltext_final.csv") %>% 
  select(-"X")

# This is the tokenised but unstemmed one
fulltext_prelim <- read.csv("data/fulltext_prelim.csv") %>% 
  select(-"X")


## Sentiment Analysis
dict_afinn = get_sentiments("afinn")

# Merge tokenized documents with the sentiment dictionary
fulltext_afinn = fulltext %>%
  group_by(uid) %>% mutate(doc_length = n()) %>%
  ungroup() %>%
  select(uid, dates, word, doc_length) %>%
  inner_join(dict_afinn, by = "word") %>%
  ungroup()

# Aggregate the sentiment score for each document
fulltext_afinn_agg = fulltext_afinn %>%
  group_by(uid, dates) %>%
  summarise(sentiment_score = sum(value) / mean(doc_length))

fulltext_afinn_agg = fulltext_prelim %>%
  select(uid, dates) %>%
  left_join(fulltext_afinn_agg) %>%
  mutate(sentiment_score = replace_na(sentiment_score, 0))

fulltext_afinn_agg$dates <- as.Date(fulltext_afinn_agg$dates)

write.csv(fulltext_afinn_agg, "data/sentiments.csv")

# Change of sentiment over time
fulltext_afinn_agg %>%
  ggplot(aes(x = dates, y = sentiment_score)) +
  geom_point(alpha = 0.8, size = 1, colour = "royalblue4") +
  geom_smooth(aes(x = dates, y = sentiment_score), colour = "black") +
  labs(
    title = "Sentiment Scores of Australian Communication"
  ) +
  scale_x_date(breaks = scales::breaks_pretty(7)) +
  xlab("Date") + ylab("Sentiment Scores (N)") + 
  theme(text = element_text(size = 15))  
