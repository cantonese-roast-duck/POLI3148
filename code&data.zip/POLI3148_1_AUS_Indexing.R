#####################################################
# Title:        Final Project: Indexing (AUS)
# Author:       Wei Tong An Richard (U3579291)
# Description:  Retrieval of links to index
#####################################################

setwd("C:/Users/user/Desktop/HKU Materials/Year 3/Y3S2/POLI3148 - Data Science/HW/Final Project/Code")

rm(list = ls())

library(tidyverse)
library(readxl)
library(xml2)

### Create separate indexes by year, and join them together
## May improve on this by running a for loop

## Indexing 2010
retrieved_index_2010 = read_html("https://china.embassy.gov.au/bjng/2010media.html")

# Selector gadget on links
retrieved_index_2010_links = retrieved_index_2010 %>%
  xml_find_all('//*[(@id = "main")]//a')

# Getting the links and titles
parsed_2010_url = retrieved_index_2010_links %>% xml_attr("href") # Get links
parsed_2010_titles = retrieved_index_2010_links %>% xml_text() # Get titles

# Getting the dates
retrieved_index_2010_dates = retrieved_index_2010 %>%
  xml_find_all('//*[(@id = "main")]//p/text()') %>% 
  xml_text()

df_2010 <- data.frame(dates = retrieved_index_2010_dates)

parsed_2010_dates <- df_2010 %>% 
  filter(str_detect(dates, c("\\/"))) # detects /

# Building index table
table_index_2010 = 
  tibble(
    dates = parsed_2010_dates$dates,
    title = parsed_2010_titles,
    url = parsed_2010_url
  )

# Ad hoc repair
table_index_2010 <- table_index_2010 %>%
  mutate(url = ifelse(!str_detect(url, "^http"),
                      str_c("http://www.china.embassy.gov.au/", url), url))


## Indexing 2011
retrieved_index_2011 = read_html("https://china.embassy.gov.au/bjng/2011media.html")

# Selector gadget on links
retrieved_index_2011_links = retrieved_index_2011 %>%
  xml_find_all('//*[(@id = "main")]//a')

# Getting the links and titles
parsed_2011_url = retrieved_index_2011_links %>% xml_attr("href") # Get links
parsed_2011_titles = retrieved_index_2011_links %>% xml_text() # Get titles

# Getting the dates
retrieved_index_2011_dates = retrieved_index_2011 %>%
  xml_find_all('//*[(@id = "main")]//p/text()') %>% 
  xml_text()

df_2011 <- data.frame(dates = retrieved_index_2011_dates)

parsed_2011_dates <- df_2011 %>% 
  filter(str_detect(dates, c("\\/"))) # detects /

# Building index table
table_index_2011 = 
  tibble(
    dates = parsed_2011_dates$dates,
    title = parsed_2011_titles,
    url = parsed_2011_url
  )

## Indexing 2012
retrieved_index_2012 = read_html("https://china.embassy.gov.au/bjng/2012media.html")

# Selector gadget on links
retrieved_index_2012_links = retrieved_index_2012 %>%
  xml_find_all('//*[(@id = "main")]//a')

# Getting the links and titles
parsed_2012_url = retrieved_index_2012_links %>% xml_attr("href") # Get links
parsed_2012_titles = retrieved_index_2012_links %>% xml_text() # Get titles

# Getting the dates
retrieved_index_2012_dates = retrieved_index_2012 %>%
  xml_find_all('//*[(@id = "main")]//p/text()') %>% 
  xml_text()

df_2012 <- data.frame(dates = retrieved_index_2012_dates)

parsed_2012_dates <- df_2012 %>% 
  filter(str_detect(dates, c("\\(|\\)"))) # detects both open OR close bracket

# Building index table
table_index_2012 = 
  tibble(
    dates = parsed_2012_dates$dates,
    title = parsed_2012_titles,
    url = parsed_2012_url
  )

## Indexing 2013
retrieved_index_2013 = read_html("https://china.embassy.gov.au/bjng/2013media.html")

# Selector gadget on links
retrieved_index_2013_links = retrieved_index_2013 %>%
  xml_find_all('//*[(@id = "main")]//a')

# Getting the links and titles
parsed_2013_url = retrieved_index_2013_links %>% xml_attr("href") # Get links
parsed_2013_titles = retrieved_index_2013_links %>% xml_text() # Get titles

# Getting the dates
retrieved_index_2013_dates = retrieved_index_2013 %>%
  xml_find_all('//*[(@id = "main")]//p/text()') %>% 
  xml_text()

df_2013 <- data.frame(dates = retrieved_index_2013_dates)

parsed_2013_dates <- df_2013 %>% 
  filter(str_detect(dates, c("\\(|\\)"))) # detects both open OR close bracket

# Building index table
table_index_2013 = 
  tibble(
    dates = parsed_2013_dates$dates,
    title = parsed_2013_titles,
    url = parsed_2013_url
  )

## Indexing 2014
retrieved_index_2014 = read_html("https://china.embassy.gov.au/bjng/2014media.html")

# Selector gadget on links
retrieved_index_2014_links = retrieved_index_2014 %>%
  xml_find_all('//*[(@id = "main")]//a')

# Getting the links and titles
parsed_2014_url = retrieved_index_2014_links %>% xml_attr("href") # Get links
parsed_2014_titles = retrieved_index_2014_links %>% xml_text() # Get titles

# Ad Hoc Cleaning
df_2014_url <- data.frame(url = parsed_2014_url)
df_2014_titles <- data.frame(titles = parsed_2014_titles)

parsed_2014_url <- df_2014_url[-c(40,42), ]
parsed_2014_titles <- df_2014_titles[-c(40,42), ]

# Getting the dates
retrieved_index_2014_dates = retrieved_index_2014 %>%
  xml_find_all('//*[(@id = "main")]//p/text()') %>% 
  xml_text()

df_2014_dates <- data.frame(dates = retrieved_index_2014_dates)

parsed_2014_dates <- df_2014_dates %>% 
  filter(str_detect(dates, c("\\(|\\)"))) # detects both open OR close bracket

# Building index table
table_index_2014 = 
  tibble(
    dates = parsed_2014_dates$dates,
    title = parsed_2014_titles,
    url = parsed_2014_url
  )

## Indexing 2015
retrieved_index_2015 = read_html("https://china.embassy.gov.au/bjng/2015media.html")

# Selector gadget on links
retrieved_index_2015_links = retrieved_index_2015 %>%
  xml_find_all('//*[(@id = "main")]//a')

# Getting the links and titles
parsed_2015_url = retrieved_index_2015_links %>% xml_attr("href") # Get links
parsed_2015_titles = retrieved_index_2015_links %>% xml_text() # Get titles

# Getting the dates
retrieved_index_2015_dates = retrieved_index_2015 %>%
  xml_find_all('//*[(@id = "main")]//p/text()') %>% 
  xml_text()

df_2015 <- data.frame(dates = retrieved_index_2015_dates)

parsed_2015_dates <- df_2015 %>% 
  filter(str_detect(dates, c("\\(|\\)"))) # detects both open OR close bracket

# Building index table
table_index_2015 = 
  tibble(
    dates = parsed_2015_dates$dates,
    title = parsed_2015_titles,
    url = parsed_2015_url
  )

## Indexing 2016
retrieved_index_2016 = read_html("https://china.embassy.gov.au/bjng/2016media.html")

# Selector gadget on links
retrieved_index_2016_links = retrieved_index_2016 %>%
  xml_find_all('//*[(@id = "main")]//a')

# Getting the links and titles
parsed_2016_url = retrieved_index_2016_links %>% xml_attr("href") # Get links
parsed_2016_titles = retrieved_index_2016_links %>% xml_text() # Get titles

# Ad hoc cleaning
df_2016_url <- data.frame(url = parsed_2016_url)
df_2016_titles <- data.frame(titles = parsed_2016_titles)

parsed_2016_url <- df_2016_url[-c(5,7,9), ]
parsed_2016_titles <- df_2016_titles[-c(5,7,9), ]

# Getting the dates
retrieved_index_2016_dates = retrieved_index_2016 %>%
  xml_find_all('//*[(@id = "main")]//p/text()') %>% 
  xml_text()

df_2016 <- data.frame(dates = retrieved_index_2016_dates)

parsed_2016_dates <- df_2016 %>% 
  filter(str_detect(dates, c("\\(|\\)"))) # detects both open OR close bracket

# Building index table
table_index_2016 = 
  tibble(
    dates = parsed_2016_dates$dates,
    title = parsed_2016_titles,
    url = parsed_2016_url
  )

## Indexing 2017
retrieved_index_2017 = read_html("https://china.embassy.gov.au/bjng/2017MediaArchive.html")

# Selector gadget on links
retrieved_index_2017_links = retrieved_index_2017 %>%
  xml_find_all('//*[(@id = "main")]//a')

# Getting the links and titles
parsed_2017_url = retrieved_index_2017_links %>% xml_attr("href") # Get links
parsed_2017_titles = retrieved_index_2017_links %>% xml_text() # Get titles

# Getting the dates
retrieved_index_2017_dates = retrieved_index_2017 %>%
  xml_find_all('//*[(@id = "main")]//p/text()') %>% 
  xml_text()

# Ad hoc cleaning
df_2017_url <- data.frame(url = parsed_2017_url)
df_2017_titles <- data.frame(titles = parsed_2017_titles)

parsed_2017_url <- df_2017_url[-c(22), ]
parsed_2017_titles <- df_2017_titles[-c(22), ]


df_2017 <- data.frame(dates = retrieved_index_2017_dates)

parsed_2017_dates <- df_2017 %>% 
  filter(str_detect(dates, c("\\(|\\)"))) %>% # detects both open OR close bracket
  add_row(dates = "(14 July 2017)") # Match Liu Xiaobo
  
parsed_2017_dates <- parsed_2017_dates[c(1:12,24,13:23),] 

# Building index table
table_index_2017 = 
  tibble(
    dates = parsed_2017_dates,
    title = parsed_2017_titles,
    url = parsed_2017_url
  )

## Indexing 2018
retrieved_index_2018 = read_html("https://china.embassy.gov.au/bjng/2018MediaArchive.html")

# Selector gadget on links
retrieved_index_2018_links = retrieved_index_2018 %>%
  xml_find_all('//*[(@id = "main")]//a')

# Getting the links and titles
parsed_2018_url = retrieved_index_2018_links %>% xml_attr("href") # Get links
parsed_2018_titles = retrieved_index_2018_links %>% xml_text() # Get titles

# Getting the dates
retrieved_index_2018_dates = retrieved_index_2018 %>%
  xml_find_all('//*[(@id = "main")]//p/text()') %>% 
  xml_text()

df_2018 <- data.frame(dates = retrieved_index_2018_dates)

parsed_2018_dates <- df_2018 %>% 
  filter(str_detect(dates, c("\\(|\\)"))) # detects both open OR close bracket

# Ad hoc cleaning
df_2018_url <- data.frame(url = parsed_2018_url)
df_2018_titles <- data.frame(titles = parsed_2018_titles)

parsed_2018_url <- df_2018_url[-c(3), ]
parsed_2018_titles <- df_2018_titles[-c(3), ]

# Building index table
table_index_2018 = 
  tibble(
    dates = parsed_2018_dates$dates,
    title = parsed_2018_titles,
    url = parsed_2018_url
  )

## Indexing 2019
retrieved_index_2019 = read_html("https://china.embassy.gov.au/bjng/2019MediaArchive.html")

# Selector gadget on links
retrieved_index_2019_links = retrieved_index_2019 %>%
  xml_find_all('//*[(@id = "main")]//a')

# Getting the links and titles
parsed_2019_url = retrieved_index_2019_links %>% xml_attr("href") # Get links
parsed_2019_titles = retrieved_index_2019_links %>% xml_text() # Get titles

# Getting the dates
retrieved_index_2019_dates = retrieved_index_2019 %>%
  xml_find_all('//*[(@id = "main")]//p/text()') %>% 
  xml_text()

df_2019 <- data.frame(dates = retrieved_index_2019_dates)

parsed_2019_dates <- df_2019 %>% 
  filter(str_detect(dates, c("\\(|\\)"))) # detects both open OR close bracket

# Building index table
table_index_2019 = 
  tibble(
    dates = parsed_2019_dates$dates,
    title = parsed_2019_titles,
    url = parsed_2019_url
  )

## Indexing 2020
retrieved_index_2020 = read_html("https://china.embassy.gov.au/bjng/2020MediaArchive.html")

# Selector gadget on links
retrieved_index_2020_links = retrieved_index_2020 %>%
  xml_find_all('//*[(@id = "main")]//a')

# Getting the links and titles
parsed_2020_url = retrieved_index_2020_links %>% xml_attr("href") # Get links
parsed_2020_titles = retrieved_index_2020_links %>% xml_text() # Get titles

# Getting the dates
retrieved_index_2020_dates = retrieved_index_2020 %>%
  xml_find_all('//*[(@id = "main")]//p/text()') %>% 
  xml_text()

df_2020 <- data.frame(dates = retrieved_index_2020_dates)

parsed_2020_dates <- df_2020 %>% 
  filter(str_detect(dates, c("\\(|\\)"))) # detects both open OR close bracket

# Building index table
table_index_2020 = 
  tibble(
    dates = parsed_2020_dates$dates,
    title = parsed_2020_titles,
    url = parsed_2020_url
  )

## Indexing 2021
retrieved_index_2021 = read_html("https://china.embassy.gov.au/bjng/2021MediaArchive.html")

# Selector gadget on links
retrieved_index_2021_links = retrieved_index_2021 %>%
  xml_find_all('//*[(@id = "main")]//a')

# Getting the links and titles
parsed_2021_url = retrieved_index_2021_links %>% xml_attr("href") # Get links
parsed_2021_titles = retrieved_index_2021_links %>% xml_text() # Get titles

# Getting the dates
retrieved_index_2021_dates = retrieved_index_2021 %>%
  xml_find_all('//*[(@id = "main")]//p/text()') %>% 
  xml_text()

df_2021 <- data.frame(dates = retrieved_index_2021_dates)

parsed_2021_dates <- df_2021 %>% 
  filter(str_detect(dates, c("\\(|\\)"))) # detects both open OR close bracket

# Ad hoc cleaning
df_2021_url <- data.frame(url = parsed_2021_url)
df_2021_titles <- data.frame(titles = parsed_2021_titles)
df_2021_dates <- data.frame(dates = parsed_2021_dates)

parsed_2021_url <- df_2021_url[-c(23), ]
parsed_2021_titles <- df_2021_titles[-c(23), ]
parsed_2021_dates <- df_2021_dates[-c(33), ]

# Building index table
table_index_2021 = 
  tibble(
    dates = parsed_2021_dates,
    title = parsed_2021_titles,
    url = parsed_2021_url
  )

## Indexing 2022
retrieved_index_2022 = read_html("https://china.embassy.gov.au/bjng/2022newsarchive.html")

# Selector gadget on links
retrieved_index_2022_links = retrieved_index_2022 %>%
  xml_find_all('//*[(@id = "main")]//a')

# Getting the links and titles
parsed_2022_url = retrieved_index_2022_links %>% xml_attr("href") # Get links
parsed_2022_titles = retrieved_index_2022_links %>% xml_text() # Get titles

# Getting the dates
retrieved_index_2022_dates = retrieved_index_2022 %>%
  xml_find_all('//*[(@id = "main")]//p/text()') %>% 
  xml_text()

df_2022 <- data.frame(dates = retrieved_index_2022_dates)

parsed_2022_dates <- df_2022 %>% 
  filter(str_detect(dates, c("\\(|\\)"))) # detects both open OR close bracket

# Building index table
table_index_2022 = 
  tibble(
    dates = parsed_2022_dates$dates,
    title = parsed_2022_titles,
    url = parsed_2022_url
  )

## Combining every year of the indexes
table_index_all <- table_index_2010 %>% 
  full_join(table_index_2011) %>% 
  full_join(table_index_2012) %>%
  full_join(table_index_2013) %>% 
  full_join(table_index_2014) %>% 
  full_join(table_index_2015) %>% 
  full_join(table_index_2016) %>% 
  full_join(table_index_2017) %>% 
  full_join(table_index_2018) %>% 
  full_join(table_index_2019) %>% 
  full_join(table_index_2020) %>% 
  full_join(table_index_2021) %>%
  full_join(table_index_2022)

# Save the full index
dir.create("data")

write_csv(table_index_all, "data/table_index_all.csv")

table_index_all <- read.csv("data/table_index_all.csv")

## Separating the index table by link type

# Creating HTML index
html_split <- table_index_all %>%
  filter(str_detect(url, ".htm")) %>% 
  mutate(uid = str_c("htm", row_number()), .before = dates)

index_html <- html_split %>% 
  filter(str_starts(url, "http")) %>% 
  mutate(uid = str_c("htm", row_number()), .before = dates)

# Creating separate HTML index for those requiring repair
index_html_2 <- html_split %>% 
  filter(str_starts(url, "/bjng")) %>% 
  mutate(url = str_c("http://www.china.embassy.gov.au/", url)) %>% 
  mutate(uid = str_c("htm_2_", row_number()), .before = dates)



# Dynamic links which cant be captured
# May need a special browser to access, eg. using selenium package in R
# index_other <- table_index_all %>%
#  filter(!str_detect(url, ".htm")) %>% 
#  filter(!str_detect(url, ".asp")) %>% 
#  filter(str_detect(url, c("trademinister")) | 
#           str_detect(url, c("foreignminister")) |
#           str_detect(url, c("afp.gov.au")) |
#           str_detect(url, c("minister.industry")) |
#           str_detect(url, c("ministers.treasury")) 
#         ) %>% 
#  mutate(uid = str_c("other", row_number()), .before = dates)
# write_csv(index_pdf, "data/index_other.csv")

# Save the files
dir.create("data")

write_csv(index_html, "data/index_html.csv")
write_csv(index_html_2, "data/index_html_2.csv")