#####################################################
# Title:        Final Project: Text Parsing (AUS)
# Author:       Wei Tong An Richard (U3579291)
# Description:  Webscraping the index links
#####################################################

setwd("C:/Users/user/Desktop/HKU Materials/Year 3/Y3S2/POLI3148 - Data Science/HW/Final Project/Code")

rm(list = ls())

library(tidyverse)
library(readxl)
library(xml2)
library(pdftools)
library(rvest)
library(readr)

dir.create("data/raw_html")
dir.create("data/parsed_html")

dir.create("data/raw_html_2")
dir.create("data/parsed_html_2")

# dir.create("data/raw_other")
# dir.create("data/parsed_other")


## For HTMLs 

rm(list = ls())
index_html <- read_csv("data/index_html.csv")

# Preferably use a trycatch, but here I manually removed the broken links
index_html <- index_html[-c(22,25,57,58,74,75,89,93,94,106,107,111,119,120,121,122,124,125,134,135,139,142,149,152,178,180,181,189,190,191,201), ]

ids <- index_html$uid
urls <- index_html$url

for (i in 121:length(ids)){ 
  doc_html <- read_html(urls[i])
  file_name_retrieved <- str_c("data/raw_html/", ids[i], ".htm")
  write_html(doc_html, file_name_retrieved)
  
  # Parsing
  text_body <- doc_html %>%
    xml_find_all('//div[(@id = "main")]')  %>% xml_text()
  
  file_name_parsed <- str_c("data/parsed_html/", ids[i], ".txt")
  write(text_body, file_name_parsed)
  
  Sys.sleep(0.5)
  message(i, " of ", length(urls))
}

## For HTML_2

rm(list = ls())

index_html_2 <- read_csv("data/index_html_2.csv")

ids <- index_html_2$uid
urls <- index_html_2$url

for (i in 1:length(ids)){ 
  doc_html <- read_html(urls[i])
  file_name_retrieved <- str_c("data/raw_html_2/", ids[i], ".htm")
  write_html(doc_html, file_name_retrieved)
  
  # Parsing
  text_body <- doc_html %>%
    xml_find_all('//div[(@id = "main")]')  %>% xml_text()
  
  file_name_parsed <- str_c("data/parsed_html_2/", ids[i], ".txt")
  write(text_body, file_name_parsed)
  
  Sys.sleep(0.5)
  message(i, " of ", length(urls))
}

## For others

# rm(list = ls())
# index_other <- read_csv("data/index_other.csv")

# Preferably use a trycatch, but here I manually removed the broken links
# index_other <- index_other[-c(1:5, 8:9), ]

# ids <- index_other$uid
# urls <- index_other$url

# for (i in 19:length(ids)){ 
#  doc_html <- read_html(urls[i])
#  file_name_retrieved <- str_c("data/raw_other/", ids[i], ".htm")
#  write_html(doc_html, file_name_retrieved)
  
  # Parsing
#  text_body <- doc_html %>%
#    xml_find_all('//div[(@id = "main")]')  %>% xml_text()
  
#  file_name_parsed <- str_c("data/parsed_other/", ids[i], ".txt")
#  write(text_body, file_name_parsed)
  
#  Sys.sleep(0.5)
#  message(i, " of ", length(urls))
# }


## Reading the text files and joining them to the index

# Index 1
rm(list = ls())

index_html <- read_csv("data/index_html.csv")
# These are the manually removed webpages as seen above
index_html <- index_html[-c(22,25,57,58,74,75,89,93,94,106,107,111,119,120,121,122,124,125,134,135,139,142,149,152,178,180,181,189,190,191,201), ]

ids <- index_html$uid

i <- 1

text_read <- c()

for (i in 1:length(ids)){ 
  retrieve_text <- str_c("data/parsed_html/", ids[i], ".txt")
  text_to_read <- read_file(retrieve_text)
  
  text_read[i] <- text_to_read
  
  Sys.sleep(0.5)
  message(i, " of ", length(ids))
}

index_html <- mutate(
  index_html, 
  text = text_read, .after = url)


# Index 2
index_html_2 <- read_csv("data/index_html_2.csv")

ids <- index_html_2$uid

i <- 1

text_read <- c()

for (i in 1:length(ids)){ 
  retrieve_text <- str_c("data/parsed_html_2/", ids[i], ".txt")
  text_to_read <- read_file(retrieve_text)
  
  text_read[i] <- text_to_read
  
  Sys.sleep(0.5)
  message(i, " of ", length(ids))
}

index_html_2 <- mutate(
  index_html_2, 
  text = text_read, .after = url)

# Joining both indexes to one
full_index <- full_join(index_html, index_html_2)

write.csv(full_index, "data/full_index.csv")

# For testing
# index_html_2 <- read_csv("data/index_html_2.csv")
# retrieve_text <- str_c("data/parsed_html_2/htm_2_1.txt")
# text_to_read <- read_file(retrieve_text)
# index_html_2 <- mutate(index_html_2, text = text_to_read, .after = url)
