#####################################################
# Title:        Final Project: Fulltext (AUS)
# Author:       Wei Tong An Richard (U3579291)
# Description:  Creating a fulltext table and applying
#               tokenisation and stemming, and removing
#               stop words
#####################################################

setwd("C:/Users/user/Desktop/HKU Materials/Year 3/Y3S2/POLI3148 - Data Science/HW/Final Project/Code")

rm(list = ls())

library(tidyverse)
library(lubridate)

## Creating a dummy index to wrangle the dates, then joining to the parsed index
## to create a fulltext table

dummy_1 <- read.csv("data/index_html.csv")
# Removed the broken links found during parsing
dummy_1 <- dummy_1[-c(22,25,57,58,74,75,89,93,94,106,107,111,119,120,121,122,124,125,134,135,139,142,149,152,178,180,181,189,190,191,201), ]

dummy_2 <- read.csv("Data/index_html_2.csv")

dummy <- full_join(dummy_1, dummy_2) %>% 
  # Ad-hoc removal
  filter(!str_detect(dates, "Media")) %>% 
  filter(!str_detect(dates, "livethelife"))

# 2011 data YYYY/MM
join_1 <- dummy %>% 
  filter(!str_detect(dates, "^2")) %>%
  filter(!str_detect(dates, "^1")) %>%
  filter(!str_detect(dates, "^\\(")) %>% 
  filter(!str_detect(dates, "^[:space:]"))

test_1 <- anti_join(dummy, join_1)

# Manually done because this is a sole case, wherein further automation to find the days 
# is problematic and logistically unjustifiable
join_1$dates <- c("2011/12/21", "2011/12/16", "2011/12/15", "2011/12/20", 
                  "2011/12/13", "2011/12/13","2011/12/02", "2011/12/01", 
                  "2011/12/02", "2011/11/3", "2011/10/24", "2011/10/14",
                  "2011/10/13", "2011/09/29", "2011/09/26", "2011/09/12", 
                  "2011/09/09", "2011/08/15", "2011/08/30", "2011/05/25", 
                  "2011/04/15")

# 2011 and 2011 data YYYY/MM/DD
join_2 <- test_1 %>% 
  filter(str_detect(dates, "^201"))

test_2 <- anti_join(test_1, join_2)

join_2$dates <- str_sub(join_2$dates, start = 1, end = 10)

# Remaining dates YYYY Month DD
join_3 <- test_2 %>% 
  filter(str_detect(dates, "^\\(")) %>% 
  filter(str_detect(dates, "\\)$"))

test_3 <- anti_join(test_2, join_3)

join_3$dates <- str_sub(join_3$dates, start = 2, end = -2)


join_4 <- test_3 %>% 
  filter(str_detect(dates, "^\\("))

test_4 <- anti_join(test_3, join_4)

join_4$dates <- str_sub(join_4$dates, start = 2, end = -3)

join_4 <- join_4 %>% 
  filter(!str_detect(dates, "y$")) # special case to be fixed 


join_5 <- test_4 %>% 
  filter(!str_detect(dates, "^[:alnum:]"))

test_5 <- anti_join(test_4, join_5)

join_5$dates <- str_sub(join_5$dates, start = 3, end = -3)


join_6 <- test_5

join_6$dates <- str_sub(join_6$dates, end = -3)


# ad hoc cleaning
join_7 <- dummy %>% 
  filter(str_detect(dates, "08 January"))

join_7$dates <- "08 January 2015" 


# Now that the dates have been wrangled, will have to unify them into the same date format
# Fixing the YYYY/MM/DD formatted dates
wrangled_yearfirst <- full_join(join_1, join_2) 

# change to unified date format
wrangled_yearfirst$dates <- ymd(wrangled_yearfirst$dates)


# Fixing the DD Month YYYY formatted dates
wrangled_dayfirst <- full_join(join_3, join_4) %>% 
  full_join(join_5) %>% 
  full_join(join_6) %>% 
  full_join(join_7)

# Ad hoc cleaning
wrangled_dayfirst[wrangled_dayfirst$uid=="htm192", "dates"] <- "21 September 2016"
wrangled_dayfirst[wrangled_dayfirst$uid=="htm193", "dates"] <- "7 September 2016"
wrangled_dayfirst[wrangled_dayfirst$uid=="htm200", "dates"] <- "8 February 2018"
wrangled_dayfirst[wrangled_dayfirst$uid=="htm_2_5", "dates"] <- "14 March 2015"
wrangled_dayfirst[wrangled_dayfirst$uid=="htm_2_15", "dates"] <- "8 October 2018"
wrangled_dayfirst[wrangled_dayfirst$uid=="htm_2_16", "dates"] <- "4 October 2018"

# Change to unified date format
wrangled_dayfirst$dates <- dmy(wrangled_dayfirst$dates)


# Joining both datasets after unifying the date format
index_dates <- full_join(wrangled_dayfirst, wrangled_yearfirst) %>% 
  select("uid", "dates")
write.csv(index_dates, "data/index_dates.csv")


## Replacing the un-wrangled dates of the index with the wrangled dates
full_index <- read.csv("data/full_index.csv") 

# Renaming so both tables can be joined
full_index <- full_index[-c(144,148),] %>% 
  select(-"X") %>% 
  rename("date" = "dates")

# Joining
fulltext_prelim <- right_join(full_index, index_dates, by = "uid") %>% 
  select(-"date")

write.csv(fulltext_prelim, "data/fulltext_prelim.csv")



## Finalising the fulltext by tokenisation, removing stop words, and stemming

# Tokenisation
library(tidytext)
fulltext_token <- fulltext_prelim %>%
  unnest_tokens("word", "text")


# Stop words
library(DT)
DT::datatable(stop_words)

# Add meaningless words to the stop words list
word <- c("chinese", "china", "china's", "australia", "australian", "australia's")
lexicon <- c("NEW", "NEW", "NEW", "NEW", "NEW", "NEW")

add_stop_words <- data.frame(word, lexicon)

new_stop_words <- full_join(stop_words, add_stop_words)


fulltext_token_stop = fulltext_token %>%
  # Remove tokenised words which match with the stop words
  anti_join(new_stop_words, by = "word")

# Stemming
library(SnowballC)

fulltext_final = fulltext_token_stop %>%
  mutate(stem = wordStem(word))


write.csv(fulltext_final, "data/fulltext_final.csv")
