#######################################################
# Title:        Final Project: Sentiment Analysis (JOINT)
# Author:       Wei Tong An Richard (U3579291)
# Description:  Doing sentiment analysis on both states
#######################################################

setwd("C:/Users/user/Desktop/HKU Materials/Year 3/Y3S2/POLI3148 - Data Science/HW/Final Project/Code")

rm(list = ls())

library(tidyverse)
library(tidytext)
library(textdata)

## Load the Australian datasets
aus_sentiments <- read.csv("data/sentiments.csv") %>% 
  select(-"X") %>% 
  # add a unique country identifier using colour
  mutate(country = "AUS", .before = uid)

aus_sentiments$dates <- as.Date(aus_sentiments$dates)

## Load the Chinese datasets
chn_sentiments <- read.csv("data_cn/sentiments.csv") %>% 
  select(-"X") %>% 
  # add a unique country identifier
  mutate(country = "CHN", .before = uid)

chn_sentiments$dates <- as.Date(chn_sentiments$dates)
chn_sentiments$uid <- as.character(chn_sentiments$uid)

## Joining the datasets

joint_sentiments <- full_join(aus_sentiments, chn_sentiments)

dir.create("data_joint")
write.csv(joint_sentiments, "data_joint/sentiments.csv")

## Plot: Change of sentiments over time
joint_sentiments %>%
  ggplot(aes(x = dates, y = sentiment_score)) +
  geom_jitter(aes(colour = country), alpha = 0.6, size = 1) +
  scale_color_manual(values = c("AUS" = "royalblue4", "CHN" = "firebrick3")) +
  geom_smooth(aes(x = dates, y = sentiment_score, colour = country)) +
  labs(
    title = "Sentiment Scores of Sino-Australian Communication",
    colour = "Country"
  ) +
  scale_x_date(breaks = scales::breaks_pretty(10)) +
  xlab("Date") + ylab("Sentiment Scores (N)") + 
  theme(text = element_text(size = 15))